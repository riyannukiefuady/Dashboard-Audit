# Dashboard Audit Internal BGI — Versi 2.0

Aplikasi audit internal PT Borneo Group Indonesia dengan **frontend HTML/CSS/JavaScript terpisah** dari **backend Node.js/Express**. Fitur inti aplikasi asal dipertahankan: ringkasan, tugas rutin, temuan, tindak lanjut, kalender, peringatan, laporan, tim/WhatsApp, pengguna, login, hak akses, unggah bukti, ekspor Excel, pengingat harian dan ekspor bulanan.

## Struktur proyek

```text
 audit-bgi/
 ├─ public/
 │  ├─ index.html              # shell halaman dashboard
 │  └─ assets/
 │     ├─ style.css            # stylesheet dashboard
 │     ├─ app.js               # logika frontend
 │     ├─ login.css            # stylesheet login
 │     └─ login.js             # logika login
 ├─ views/login.html           # halaman login
 ├─ server.js                  # backend, API, autentikasi, penyimpanan
 ├─ package.json
 ├─ .env.example
 └─ README.md
```

## Menjalankan lokal di VS Code

1. Instal Node.js 18 atau lebih baru.
2. Ekstrak ZIP dan buka folder proyek di VS Code.
3. Buka terminal, jalankan `npm install`.
4. Salin `.env.example` menjadi `.env`.
5. Ubah `ADMIN_PASSWORD` menjadi password awal yang kuat. Untuk pengembangan lokal, `COOKIE_SECURE=false` dapat dipakai bila server diakses langsung melalui HTTP.
6. Jalankan `npm start` atau `npm run dev`.
7. Buka `http://localhost:3000`.

Jika `ADMIN_PASSWORD` dikosongkan, server membuat password acak dan menampilkannya sekali di terminal. Segera ganti password melalui menu di aplikasi.

## Deploy online

Aplikasi ini **bukan website statis**. GitHub dipakai untuk menyimpan source code; jalankan backend pada layanan hosting yang mendukung Node.js 18+ (misalnya Render, Railway, atau VPS). GitHub Pages saja tidak dapat menjalankan `server.js`, API, sesi login, upload, atau cron.

Konfigurasi umum platform hosting:

- Build command: `npm install`
- Start command: `npm start`
- Runtime: Node.js 18 atau lebih baru
- Environment variables: `HOST=0.0.0.0`, `TZ=Asia/Jakarta`, `TRUST_PROXY=1`, `COOKIE_SECURE=true`, `ADMIN_PASSWORD=<password-kuat>`.
- Atur `PORT` melalui environment platform (server membaca `process.env.PORT`).
- Aktifkan HTTPS pada domain/hosting.

### Penyimpanan persisten wajib

Versi ini mempertahankan penyimpanan JSON lokal pada `data/`, file bukti pada `uploads/`, dan ekspor pada `exports/`. Banyak platform cloud menggunakan filesystem sementara yang dapat terhapus saat redeploy/restart. Untuk penggunaan produksi, pasang persistent disk/volume dan arahkan direktori data ke volume tersebut, atau migrasikan penyimpanan ke database terkelola dan object storage. Jangan mengandalkan filesystem sementara untuk data audit perusahaan.

## GitHub upload

```bash
git init
git add .
git commit -m "Dashboard Audit BGI v2"
git branch -M main
git remote add origin https://github.com/USERNAME/REPOSITORY.git
git push -u origin main
```

Jangan commit `.env`, folder `data/`, `uploads/`, `exports/`, password, token Fonnte, atau data audit nyata. `.gitignore` sudah mengecualikan lokasi tersebut.

## Akun dan hak akses

| Peran | Hak akses |
|---|---|
| Admin | Seluruh data dan pengelolaan pengguna/tim |
| Auditor | Melihat semua; mengelola tugas, temuan, tindak lanjut miliknya |
| Auditee | Melihat tindak lanjut yang menjadi tanggung jawabnya dan memperbarui progres/bukti |
| Pimpinan | Melihat data tanpa mengubah |

Untuk Auditor, kolom Nama pada akun harus sama dengan nama auditor pada tab Tim. Untuk Auditee, samakan dengan nama PIC pada tindak lanjut.

## Fitur otomatis

- Pengingat WhatsApp harian menggunakan Fonnte, bila `FONNTE_TOKEN` diisi.
- Ekspor Excel bulanan ke `exports/`.
- Pengiriman email opsional menggunakan variabel `SMTP_*` dan `EMAIL_TO`.
- Uji manual: `npm run pengingat` dan `npm run ekspor`.

## Pemeriksaan kode

Jalankan `npm run check` untuk memeriksa sintaks JavaScript.

## Catatan keamanan dan operasional

- Gunakan HTTPS untuk semua akses online.
- Gunakan password unik dan kuat; jangan membagikan akun Admin.
- Backup rutin database dan bukti audit.
- File bukti yang diunggah hanya boleh menggunakan tipe yang diizinkan backend.
- Sesi login berjalan di memori server selama 8 jam; restart server akan mengeluarkan pengguna. Untuk multi-instance/produksi skala besar, gunakan session store terkelola.
- Tinjau kebutuhan retensi arsip, backup, dan pemulihan sebelum digunakan sebagai sistem pencatatan resmi perusahaan.
